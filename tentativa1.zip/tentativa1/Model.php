<?php

require_once('Config.php');

class Model2
{
    private static $instance; 

    public static function Conexao(){

        if (!self::$instance) {

            self::$instance = new PDO('mysql:host='.HOST.';dbname='.DATABASE, USER, PASS, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
            self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        }

        return self::$instance;
    }
    
}

