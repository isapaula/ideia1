<?php

require_once 'Controller.php';

$controller = new Controller();
  

if (isset($_POST['dados'])) {
        
    $assunto =  isset($_POST['assunto']) ? $_POST['assunto'] : "digite este campo";  
    $status =  isset($_POST['status']) ? $_POST['status']  :  "digite este campo";
    $grupo =  isset($_POST['grupo']) ? $_POST['grupo'] :  "digite este campo";
    $analista =  isset($_POST['analista']) ? $_POST['analista'] :  "digite este campo";
    $produto =  isset($_POST['produto']) ? $_POST['produto'] :  "digite este campo";
    $descricao =  isset($_POST['descricao']) ? $_POST['descricao'] :  "digite este campo";


    $controller->create($assunto,$status,$grupo,$analista,$produto, $descricao); 

     header("Location: Controller.php");

} 
