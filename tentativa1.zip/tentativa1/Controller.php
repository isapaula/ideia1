<?php

require_once('Model.php');

class Controller
{
    public function create($assunto, $status, $grupo, $analista, $produto, $descricao) {

        try {

            $stmt = Model2::Conexao();
            
            $sql = "INSERT INTO tickets(assunto,statusTicket,grupo,analista,produto,descricao) VALUES (?,?, ?, ?, ?,? )"; 

            $create =  $stmt->prepare($sql);

                    $create->bindParam(1, $assunto, PDO::PARAM_STR);
                    $create->bindParam(2, $status, PDO::PARAM_STR);
                    $create->bindParam(3, $grupo, PDO::PARAM_STR);
                    $create->bindParam(4, $analista, PDO::PARAM_STR);
                    $create->bindParam(5, $produto, PDO::PARAM_STR);
                    $create->bindParam(6, $descricao,  PDO::PARAM_STR);

                    $create->execute();


                    $auth = base64_encode(USERNAME,API_KEY);
                    
                    $data = array(
                        'fields' => array(
                            'project' => array('key' => 'FIRST'),
                            'summary' => $assunto,
                            'description' => $descricao,
                            'issuetype' => 'Tarefa',
                        ),
                    );

                   

                        $json_data = json_encode($data);
                        
                        var_dump($json_data);

                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_URL, URI);
                        curl_setopt($ch, CURLOPT_POST, true);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                            'Content-Type: application/json',
                            'Authorization: Basic ' . $auth,
                        ));
                        
                        $result = curl_exec($ch);

                        $ch_erros = curl_error($ch);

                        if ($ch_erros) {
                            return "Erro: "+$ch_erros;
                        }else{
                            return var_dump($result);
                        }

                        curl_close($ch);
                 

        } catch (PDOException $e) {
            echo $e->getMessage(); 
        }

    }


    
}
