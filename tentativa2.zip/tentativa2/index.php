<?php
require 'vendor/autoload.php';


use JiraRestApi\Issue\IssueService;
use JiraRestApi\Issue\IssueField;
use JiraRestApi\JiraException;

try {
    $issueField = new IssueField();

    $issueField->setProjectKey('FIRST')
                ->setSummary('something\s wrong')
                ->setIssueType('titulo')
                ->setDescription('Full description for issue')
                // set issue security if you need.
                ->setSecurityId(10001 /* security scheme id */)
            ;
	
    $issueService = new IssueService();

    $ret = $issueService->create($issueField);
	
    //If success, Returns a link to the created issue.
    var_dump($ret);
} catch (JiraException $e) {
	print('Error Occured! ' . $e->getMessage());
}